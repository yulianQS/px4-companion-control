"""Offline verification of board parameter export and local path confinement."""
import io
import json
from pathlib import Path
import tempfile
import threading
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from web.server.parameter_snapshot import snapshot
from scripts import local_parameter_sync as local


class Store:
    lock = threading.Lock()


class Response(io.BytesIO):
    pass


class Opener:
    def __init__(self, payload):
        self.payload = payload

    def open(self, url, timeout):
        assert url == local.BOARD + '/api/parameters/export'
        return Response(json.dumps(self.payload).encode())


def run():
    with tempfile.TemporaryDirectory(prefix='parameter-sync-') as temp:
        root = Path(temp)
        board, pc = root / 'board', root / 'pc'
        for p in (board / 'config', board / 'missions', pc / 'config'):
            p.mkdir(parents=True)
        (board / 'config' / 'vision_control.json').write_text('{"speed": 4}', encoding='utf-8')
        (board / 'config' / 'web_access_token').write_text('secret', encoding='utf-8')
        (board / 'missions' / 'test.json').write_text('{"id": "test"}', encoding='utf-8')
        exported = snapshot(board, Store())
        assert set(exported['files']) == {'config/vision_control.json', 'missions/test.json'}
        local.ROOT = pc
        local.build_opener = lambda *args: Opener({'ok': True, **exported})
        assert local.synchronize() == 2
        assert json.loads((pc / 'config' / 'vision_control.json').read_text(encoding='utf-8'))['speed'] == 4
        assert json.loads((pc / 'missions' / 'test.json').read_text(encoding='utf-8'))['id'] == 'test'
        bad = {'ok': True, 'version': 1, 'files': {'../escape.json': '{}'}}
        local.build_opener = lambda *args: Opener(bad)
        try:
            local.synchronize()
        except ValueError:
            pass
        else:
            raise AssertionError('unsafe path accepted')
        assert not (root / 'escape.json').exists()
        print('PASS: parameter export, saved mission sync, credentials excluded and paths confined')


if __name__ == '__main__':
    run()
