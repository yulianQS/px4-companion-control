"""Exercise repeated distance tasks with a PTY fake PX4 on the computer only."""
import json, os, socket, subprocess, sys, tempfile, threading, time
from pathlib import Path
from verify_cpp_service import FakePX4, wait
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from web.server.cpp_bridge import FlightConsole
from web.server.mission_client import MissionClient
from web.server.vision_control_config import VisionControlConfig, DEFAULTS

def run(binary):
 fake=FakePX4(); done=threading.Event(); distance=[3.14]; process=console=None
 with tempfile.TemporaryDirectory(prefix='scaled-offset-pty-') as temp:
  root=Path(temp);(root/'vision').mkdir();(root/'config').mkdir()
  (root/'config/mission_blocks.json').write_bytes((Path(__file__).resolve().parents[1]/'config/mission_blocks.json').read_bytes())
  VisionControlConfig(root/'config/vision_control.json').save(dict(DEFAULTS,forward_speed_m_s=3.))
  def publish():
   while not done.is_set():
    t=time.monotonic();sample=dict(source='ros2_cpp',written_monotonic=t,observation_monotonic=t,camera_ready=True,target_found=True,tag_id=0,center=[319.5,239.5],width=640,height=480,measurement_age_s=.01,pose_valid=True,calibrated=True,tag_size_m=.12,distance_m=distance[0],translation_m=[0.,0.,distance[0]])
    p=root/'vision/status.tmp';p.write_text(json.dumps(sample));p.replace(root/'vision/status.json');done.wait(.03)
  thread=threading.Thread(target=publish,daemon=True)
  try:
   with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
   thread.start();fake.thread.start();process=subprocess.Popen([str(binary),'--device',fake.device,'--port',str(port),'--logs',str(root/'flights')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=dict(os.environ,DRONE_PROJECT_ROOT=str(root),DRONE_VISION_SNAPSHOT_DIR=str(root/'vision')))
   console=FlightConsole(port=port);console.start();owner='scaled-offset-owner';state=lambda:console.status()['data']
   wait(lambda:state()['px4'].get('bidirectional'),8)
   assert console.client.request('CLAIM',{},owner)['ok'];assert console.client.request('SET_MODE',{'mode':'OFFBOARD'},owner)['confirmed'];assert console.client.request('ARM',{},owner)['confirmed']
   fake.xyz[2]=-.5;fake.landed=2;wait(lambda:state()['px4'].get('landed_state')==2)
   blocks=[dict(id='align',type='align',name='align',branches={},timeout=15,next='distance',params=dict(coarse_alignment_frames=1)),dict(id='distance',type='distance',name='distance',branches={},timeout=15,next='align',params=dict(duration_mode='auto',duration_offset=.6,forward_speed_override=3.))]
   engine=MissionClient(console);doc=dict(version=1,id='scaled-test',name='scaled-test',entry='align',blocks=blocks);engine.start(doc,owner)
   events=lambda:[e for e in engine.status()['events'] if e['event']=='distance_duration_calculated']
   wait(lambda:len(events())>=1,8);first=events()[0];assert abs(first['distance_m']-3.14)<.001 and abs(first['offset_s']-.6)<.001
   distance[0]=2.56;wait(lambda:len(events())>=2,8);second=events()[1]
   assert abs(second['distance_m']-2.56)<.001 and abs(second['reference_distance_m']-3.14)<.001,second
   assert abs(second['offset_s']-.6*2.56/3.14)<.001 and abs(second['duration_s']-(2.56/3+.6*2.56/3.14))<.001,second
   engine.stop('hold',owner);wait(lambda:not engine.status()['active'],5)
   distance[0]=2.;doc['blocks'][1]['params']['duration_offset']=-.3;time.sleep(.3);engine.start(doc,owner);wait(lambda:any(e['event']=='distance_duration_calculated' for e in engine.status()['events']),8)
   fresh=next(e for e in engine.status()['events'] if e['event']=='distance_duration_calculated');assert abs(fresh['reference_distance_m']-2.)<.001 and abs(fresh['offset_s']+.3)<.001,fresh
   distance[0]=1.;wait(lambda:len(events())>=2,8);negative=events()[1];assert abs(negative['offset_s']+.15)<.001,negative
   engine.stop('hold',owner);wait(lambda:not engine.status()['active'],5)
   print('PASS: first offset, scaled second offset, and reference reset on new run')
  finally:
   done.set()
   if console:console.stop()
   if process:
    process.terminate()
    try:process.communicate(timeout=8)
    except subprocess.TimeoutExpired:process.kill();process.communicate()
   if thread.is_alive():thread.join(2)
   fake.close()
   if hasattr(fake,'error'):raise fake.error
if __name__=='__main__':run(Path(sys.argv[1]).resolve())
