"""MAVLink message-rate negotiation against local PTY only; never hardware."""
from pathlib import Path
import socket,subprocess,sys,tempfile,time
from verify_cpp_service import FakePX4,ServiceClient,wait

def scenario(binary,ack,armed):
 fake=FakePX4();fake.armed=armed;fake.interval_result=ack;fake.send_external_odometry=True
 client=process=None
 with tempfile.TemporaryDirectory(prefix='odometry-rate-pty-') as temp:
  try:
   with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
   fake.thread.start();process=subprocess.Popen([str(binary),'--device',fake.device,'--port',str(port),'--logs',temp],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
   client=ServiceClient(port=port);client.start();state=lambda:client.status()['data']['px4']
   wait(lambda:state().get('bidirectional'),8)
   if armed:
    time.sleep(1);assert not any(c.command==511 for c in fake.commands);assert state()['odometry_rate_request']=='waiting_disarmed'
    fake.armed=False
   wait(lambda:state().get('odometry_rate_request') in ('accepted','rejected'),6)
   s=state(); expected='accepted' if ack==0 else 'rejected';assert s['odometry_rate_request']==expected,s
   requests=[c for c in fake.commands if c.command==511];assert len(requests)==1 and requests[0].param1==331 and requests[0].param2==200000,requests
   wait(lambda:state()['odometry_other_count']>2 and state()['odometry_autopilot_count']>2)
   assert state()['odometry_reset_counter']==fake.epoch,'External source must not replace flight controller reset counter'
   owner='rate-stale-safety-test'
   assert client.request('CLAIM',{},owner)['ok']
   assert client.request('SET_MODE',{'mode':'OFFBOARD'},owner)['confirmed']
   assert client.request('ARM',{},owner)['confirmed']
   fake.send_odometry=False;wait(lambda:state()['odometry_age_s']>1.2,4)
   assert state()['odometry_reset_counter']==fake.epoch and state()['odometry_other_count']>2
   result=client.request('TAKEOFF',{'height':.5},owner)
   assert result.get('stage')=='failed' and 'Fresh EKF' in result.get('message',''),result
   time.sleep(.5);assert len([c for c in fake.commands if c.command==511])==1,'No silent retry after ACK'
  finally:
   if client:client.stop()
   if process:process.terminate();process.communicate(timeout=8)
   fake.close()
   if hasattr(fake,'error'):raise fake.error
if __name__=='__main__':
 binary=Path(sys.argv[1]).resolve()
 for ack,armed in [(0,False),(2,False),(0,True)]:scenario(binary,ack,armed)
 print('PASS: 5 Hz request, ACK accept/reject, disarmed gate, source filtering and stale flight-controller odometry')
