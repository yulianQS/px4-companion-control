"""Local-only bridge for copying saved board parameters into this checkout.

Run on the computer displaying the board webpage; browser requests cannot choose paths.
"""
import json
import os
from pathlib import Path
import re
import tempfile
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.request import ProxyHandler, build_opener

ROOT = Path(__file__).resolve().parents[1]
BOARD = 'http://10.77.82.22:8081'
ORIGIN = BOARD
PORT = 18765
CONFIG = {'config/runtime.json', 'config/vision_control.json', 'config/vision.yaml',
          'config/camera_intrinsics.yaml', 'config/camera_intrinsics_source.json'}
MISSION = re.compile(r'^missions/[A-Za-z0-9_-]{1,100}\.json$')
LOCK = threading.Lock()


def synchronize():
    opener = build_opener(ProxyHandler({}))
    with opener.open(BOARD + '/api/parameters/export', timeout=10) as response:
        data = response.read(16 * 1024 * 1024 + 1)
    if len(data) > 16 * 1024 * 1024:
        raise ValueError('板端响应过大')
    payload = json.loads(data)
    files = payload.get('files')
    if payload.get('ok') is not True or payload.get('version') != 1 or not isinstance(files, dict):
        raise ValueError('板端参数格式无效')
    checked = []
    for relative, content in files.items():
        if not isinstance(relative, str) or not (relative in CONFIG or MISSION.fullmatch(relative)):
            raise ValueError('板端包含不允许同步的路径')
        if not isinstance(content, str) or not content.strip() or len(content.encode('utf-8')) > 262144:
            raise ValueError('参数文件内容无效：' + relative)
        if relative.endswith('.json'):
            json.loads(content)
        target = ROOT / relative
        if not target.resolve().is_relative_to(ROOT) or target.is_symlink():
            raise ValueError('目标路径不在本地工程内：' + relative)
        checked.append((target, content))
    if not checked:
        raise ValueError('板端没有可同步参数')
    with LOCK:
        for target, content in checked:
            target.parent.mkdir(parents=True, exist_ok=True)
            pending = None
            try:
                with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8', newline='',
                                                 dir=target.parent, prefix='.sync-', delete=False) as stream:
                    pending = stream.name
                    stream.write(content)
                    stream.flush()
                    os.fsync(stream.fileno())
                os.replace(pending, target)
            finally:
                if pending and os.path.exists(pending):
                    os.unlink(pending)
    return len(checked)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def reply(self, code, value):
        data = json.dumps(value, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        if self.headers.get('Origin') == ORIGIN:
            self.send_header('Access-Control-Allow-Origin', ORIGIN)
            self.send_header('Vary', 'Origin')
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.send_header('Cache-Control', 'no-store')
        self.end_headers()
        self.wfile.write(data)

    def allowed(self):
        return (self.client_address[0] == '127.0.0.1' and self.headers.get('Origin') == ORIGIN
                and self.headers.get('Host') == '127.0.0.1:' + str(PORT))

    def do_OPTIONS(self):
        if not self.allowed() or self.path != '/sync':
            self.reply(403, {'ok': False})
            return
        self.send_response(204)
        self.send_header('Access-Control-Allow-Origin', ORIGIN)
        self.send_header('Access-Control-Allow-Methods', 'POST')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.send_header('Access-Control-Allow-Private-Network', 'true')
        self.send_header('Vary', 'Origin')
        self.end_headers()

    def do_POST(self):
        if not self.allowed() or self.path != '/sync' or self.headers.get('Content-Length', '0') != '0':
            self.reply(403, {'ok': False, 'message': '请求来源不允许'})
            return
        try:
            count = synchronize()
            self.reply(200, {'ok': True, 'count': count})
        except (OSError, ValueError, UnicodeError) as error:
            self.reply(503, {'ok': False, 'message': str(error)})


if __name__ == '__main__':
    ThreadingHTTPServer(('127.0.0.1', PORT), Handler).serve_forever()
