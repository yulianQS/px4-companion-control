const assert=require('node:assert/strict');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE);
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:process.env.CHROME_PATH});
 try{
  const page=await browser.newPage();await page.goto('http://127.0.0.1:8082/#mission');
  await page.waitForSelector('.mission-block[data-type="distance"]');
  await page.locator('.mission-block[data-type="distance"]').click();
  await page.locator('#mission-list>li').last().getByRole('button',{name:'配置 距离保持',exact:true}).click();
  const mode=page.locator('#mission-param-duration_mode'),duration=page.locator('#mission-param-duration'),offset=page.locator('#mission-param-duration_offset');
  assert.equal(await mode.inputValue(),'manual');assert(await duration.isVisible());assert(!(await offset.isVisible()));
  const speed=page.locator('#mission-param-forward_speed_override');assert.equal(await speed.inputValue(),'');await speed.fill('1.5');await duration.fill('0.5');await mode.selectOption('auto');assert(!(await duration.isVisible()));assert(await offset.isVisible());await offset.fill('-0.2');
  await page.getByRole('button',{name:'保存参数',exact:true}).click();await page.waitForFunction(()=>!document.getElementById('mission-params-dialog').open);
  await page.locator('#mission-list>li').last().getByRole('button',{name:'配置 距离保持',exact:true}).click();
  assert.equal(await mode.inputValue(),'auto');assert.equal(await speed.inputValue(),'1.5');assert.equal(await offset.inputValue(),'-0.2');await mode.selectOption('manual');assert.equal(await duration.inputValue(),'0.5');
  console.log('PASS: manual/auto switch, 0.5s manual value and negative adjustment retained');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
