"""Mission relative moves on a new PTY; no physical UART or flight dynamics."""
import json
import math
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile
import time
from verify_cpp_service import FakePX4, ServiceClient, wait


def run():
    binary = Path(sys.argv[1]).resolve()
    fake = FakePX4()
    assert fake.device.startswith('/dev/pts/')
    client = process = None
    with tempfile.TemporaryDirectory(prefix='move-leveling-pty-') as temp:
        try:
            with socket.socket() as probe:
                probe.bind(('127.0.0.1', 0)); port = probe.getsockname()[1]
            fake.thread.start()
            # Mission validation reads only this sandbox's catalogue.
            root = Path(temp)
            (root/'config').mkdir()
            (root/'config/mission_blocks.json').write_bytes(
                (Path(__file__).resolve().parents[1]/'config/mission_blocks.json').read_bytes())
            process = subprocess.Popen([str(binary), '--device', fake.device, '--port', str(port),
                                        '--logs', temp], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                       env=dict(os.environ, DRONE_PROJECT_ROOT=temp))
            client = ServiceClient(port=port); client.start()
            owner = 'move-leveling-pty-owner'
            state = lambda: client.status()['data']
            command = lambda name, params=None: client.request(name, params or {}, owner)
            wait(lambda: state()['px4'].get('bidirectional'), 8)
            assert command('CLAIM')['ok']
            assert command('SET_MODE', {'mode':'OFFBOARD'})['confirmed']
            assert command('ARM')['confirmed']
            fake.xyz = [0., 0., -.5]; fake.landed = 2
            wait(lambda: state()['px4'].get('landed_state') == 2)

            def motion(): return state()['motion']
            def start(direction='forward', phase='moving', **params):
                doc = dict(version=1, id='level-test', name='level-test', entry='move', blocks=[
                    dict(id='move', type='move', name='move', next=None, branches={}, timeout=8,
                         params=dict(direction=direction, distance=.3, speed=.6, acceleration=0,
                                     tolerance=.03, **params))])
                result = command('MISSION_START', doc)
                assert result['ok'], result
                wait(lambda: state()['mission'].get('active') and motion().get('state') == 'running'
                     and motion().get('phase') == phase)
                return len(fake.setpoints)
            def held(first):
                points = [m for _, m in fake.setpoints[first:]]
                assert len(points) >= 2
                assert all(m.type_mask & 3 == 3 and not m.type_mask & 4 for m in points)
                assert all(abs(m.vx)+abs(m.vy)+abs(m.vz) < 1e-6 for m in points)
                assert all(abs(m.z + .5) < .001 for m in points)
            def finished(expected):
                wait(lambda: not state()['mission'].get('active'), 6)
                result = state()['mission']
                assert result['state'] == expected, result
                return result

            # Legacy direct MOVE retains its existing interface and does not gain a gate.
            fake.pitch = .8
            result = command('MOVE', dict(kind='move', direction='forward', distance=.1,
                                         speed=.2, acceleration=0, tolerance=.02))
            assert result['stage'] == 'running', result
            wait(lambda: motion().get('state') == 'succeeded')
            assert motion().get('phase') != 'leveling'

            # Backward missions start immediately, even with tilt and forward velocity.
            fake.follow_setpoints = False
            fake.heading = .4; fake.pitch = .8; fake.reported_velocity = [.5, 0., 0.]
            wait(lambda: abs(state()['px4']['attitude_deg'][2] - .4*180/math.pi) < .1)
            first = start('back', phase='moving')
            moving = motion()
            origin, goal = moving['start_position'], moving['goal_position']
            assert abs(goal[0] - origin[0] + .3*math.cos(.4)) < .001
            assert abs(goal[1] - origin[1] + .3*math.sin(.4)) < .001
            wait(lambda: any(m.vx*math.cos(.4) + m.vy*math.sin(.4) < -.1
                             for _, m in fake.setpoints[first:]))
            assert command('MISSION_STOP', {'mode':'hold'})['ok']
            finished('stopped')
            fake.reported_velocity = [0., 0., 0.]

            # All other directions start despite tilt and residual velocity.
            # The fake PX4 does not model braking or actual flight dynamics.
            fake.follow_setpoints = False
            fake.heading = .4; fake.pitch = .8; fake.roll = .3
            fake.reported_velocity = [.5, 0., 0.]
            for direction in ('forward', 'left', 'right', 'up', 'down'):
                first = start(direction, level_settle_s=5, level_timeout_s=1)
                assert motion()['phase'] == 'moving'
                wait(lambda: len(fake.setpoints) > first + 2)
                assert command('MISSION_STOP', {'mode':'hold'})['ok']
                finished('stopped')
            # Brake follows the initial NED velocity, not heading; roll and pitch
            # do not gate completion. The fake does not model flight dynamics.
            fake.reported_velocity = [.3, .4, 0.]
            wait(lambda: abs(state()['px4']['local_position']['vy'] - .4) < .01)
            doc = dict(version=1, id='brake-test', name='brake-test', entry='brake', blocks=[
                dict(id='brake', type='pitch_brake', name='brake', next=None, branches={}, timeout=8,
                     params=dict(reverse_speed=1., brake_timeout=5))])
            first = len(fake.setpoints)
            assert command('MISSION_START', doc)['ok']
            wait(lambda: motion().get('phase') == 'braking')
            wait(lambda: any(abs(m.vx + .6) < .02 and abs(m.vy + .8) < .02 and
                             abs(m.vz) < .001 and m.type_mask & 7 == 7
                             for _, m in fake.setpoints[first:]))
            fake.reported_velocity = [-.06, -.08, 0.]
            finished('succeeded')
            assert motion()['phase'] == 'completed'
            # A following relative move must receive control without an intervening
            # captured-position hold after the brake reports reverse motion.
            fake.reported_velocity = [.3, .4, 0.]
            wait(lambda: abs(state()['px4']['local_position']['vy'] - .4) < .01)
            doc['blocks'][0]['next'] = 'move'
            doc['blocks'].append(dict(id='move', type='move', name='move', next=None, branches={}, timeout=8,
                                      params=dict(direction='back', distance=.3, speed=.6,
                                                  acceleration=0, tolerance=.03)))
            first = len(fake.setpoints)
            assert command('MISSION_START', doc)['ok']
            wait(lambda: motion().get('phase') == 'braking')
            wait(lambda: any(abs(m.vx + .6) < .02 and abs(m.vy + .8) < .02
                             for _, m in fake.setpoints[first:]))
            fake.reported_velocity = [-.06, -.08, 0.]
            wait(lambda: motion().get('params', {}).get('kind') == 'move')
            wait(lambda: any(m.type_mask & 3 == 0 for _, m in fake.setpoints[first:]))
            points = [m for _, m in fake.setpoints[first:]]
            reverse_index = next(i for i, m in enumerate(points)
                                 if abs(m.vx + .6) < .02 and abs(m.vy + .8) < .02)
            move_index = next(i for i in range(reverse_index + 1, len(points))
                              if points[i].type_mask & 3 == 0)
            assert all(m.type_mask & 7 == 7 for m in points[reverse_index:move_index])
            assert command('MISSION_STOP', {'mode':'hold'})['ok']
            finished('stopped')
            # Speeds below the former 0.05 m/s gate are accepted.
            doc['blocks'] = doc['blocks'][:1]
            doc['blocks'][0]['next'] = None
            fake.reported_velocity = [.01, 0., 0.]
            wait(lambda: abs(state()['px4']['local_position']['vx'] - .01) < .001)
            assert command('MISSION_START', doc)['ok']
            wait(lambda: motion().get('phase') == 'braking')
            fake.reported_velocity = [-.01, 0., 0.]
            finished('succeeded')
            # With zero current velocity, use recent actual velocity samples.
            fake.reported_velocity = [.3, 0., 0.]
            time.sleep(.5)
            fake.reported_velocity = [0., 0., 0.]
            wait(lambda: state()['px4']['local_position']['vx'] == 0.)
            first = len(fake.setpoints)
            assert command('MISSION_START', doc)['ok']
            wait(lambda: motion().get('phase') == 'braking')
            wait(lambda: any(m.vx < -.9 for _, m in fake.setpoints[first:]))
            fake.reported_velocity = [-.01, 0., 0.]
            finished('succeeded')
            print('PASS: relative moves, reverse braking and handoff')
        finally:
            if client: client.stop()
            if process:
                process.terminate(); out, err = process.communicate(timeout=8)
                assert process.returncode == 0, (out, err)
            fake.close()
            assert not hasattr(fake, 'error'), getattr(fake, 'error', None)


if __name__ == '__main__': run()
