"""Mission loss/timeout behavior using only a fake PX4 on a fresh PTY."""
import json, os, socket, subprocess, sys, tempfile, threading, time
from pathlib import Path
from verify_cpp_service import FakePX4, wait
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from web.server.cpp_bridge import FlightConsole
from web.server.mission_client import MissionClient

def run():
    binary=Path(sys.argv[1]).resolve(); fake=FakePX4(); done=threading.Event(); visible=threading.Event()
    assert fake.device.startswith('/dev/pts/')
    with tempfile.TemporaryDirectory(prefix='mission-wait-') as td:
        root=Path(td); (root/'vision').mkdir(); (root/'config').mkdir()
        (root/'config/mission_blocks.json').write_bytes((Path(__file__).resolve().parents[1]/'config/mission_blocks.json').read_bytes())
        def publisher():
            while not done.is_set():
                stamp=time.monotonic(); data=dict(source='ros2_cpp',written_monotonic=stamp,observation_monotonic=stamp,camera_ready=True,target_found=visible.is_set(),tag_id=0,center=[319.5,239.5],width=640,height=480,measurement_age_s=.01,pose_valid=True,calibrated=True,tag_size_m=.12,distance_m=2.,translation_m=[0,0,2.])
                p=root/'vision/status.tmp';p.write_text(json.dumps(data));p.replace(root/'vision/status.json');done.wait(.03)
        thread=threading.Thread(target=publisher,daemon=True);process=console=None
        try:
            with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
            thread.start();fake.thread.start()
            env=dict(os.environ,DRONE_PROJECT_ROOT=str(root),DRONE_VISION_SNAPSHOT_DIR=str(root/'vision'))
            process=subprocess.Popen([str(binary),'--device',fake.device,'--port',str(port),'--logs',str(root/'flights')],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            console=FlightConsole(port=port);console.start(); owner='mission-wait-test'; state=lambda:console.status()['data']
            wait(lambda:state()['px4'].get('bidirectional'),8)
            assert console.client.request('CLAIM',{},owner)['ok'];assert console.client.request('SET_MODE',{'mode':'OFFBOARD'},owner)['confirmed'];assert console.client.request('ARM',{},owner)['confirmed']
            fake.xyz[2]=-.5;fake.landed=2;wait(lambda:state()['px4'].get('landed_state')==2)
            engine=MissionClient(console)
            blocks=[dict(id='a',type='align',name='align',params=dict(lost_timeout=.3),branches={},timeout=2,next='d'),dict(id='d',type='distance',name='distance',params=dict(lost_timeout=.3,duration=5),branches={},timeout=2,next=None)]
            engine.start(dict(version=1,id='wait',name='wait',entry='a',blocks=blocks),owner)
            wait(lambda:engine.status().get('current_id')=='a',5);time.sleep(3)
            status=engine.status();assert status['active'] and status['current_id']=='a',status
            assert any(e['event']=='block_overdue' for e in status['events']); assert not any(e.get('command')=='VISION_STOP' for e in status['events'])
            visible.set();wait(lambda:engine.status().get('current_id')=='d',8)
            visible.clear();time.sleep(3);status=engine.status();assert status['active'] and status['current_id']=='d',status
            assert sum(e.get('command')=='VISION_START' for e in status['events'])==1
            assert not any(e.get('command')=='VISION_STOP' for e in status['events'])
            engine.stop('hold');wait(lambda:not engine.status()['active'],5)
            # A basic motion's own timeout must not end an accepted mission either.
            assert console.client.request('CLAIM',{},owner)['ok'];fake.follow_setpoints=False
            b=dict(id='m',type='move',name='move',params=dict(direction='forward',distance=1,speed=.1),branches={},timeout=2,next=None)
            engine.start(dict(version=1,id='move-wait',name='move-wait',entry='m',blocks=[b]),owner)
            wait(lambda:engine.status().get('current_id')=='m',5);time.sleep(3)
            status=engine.status();assert status['active'] and any(e['event']=='block_overdue' for e in status['events']),status
            engine.stop('hold');wait(lambda:not engine.status()['active'],5)
            # Exhausting a search round without a target starts another round.
            fake.follow_setpoints=True;assert console.client.request('CLAIM',{},owner)['ok']
            search=dict(id='s',type='search',name='search',params=dict(scan_angle=4,scan_speed=90,forward_distance=.1,speed=.5,max_attempts=1),branches={},timeout=2,next=None)
            engine.start(dict(version=1,id='search-wait',name='search-wait',entry='s',blocks=[search]),owner)
            wait(lambda:any(e['event']=='search_cycle_restart' for e in engine.status()['events']),25)
            assert engine.status()['active'];engine.stop('hold');wait(lambda:not engine.status()['active'],5)
            # Genuine heartbeat loss must still fail the mission.
            fake.follow_setpoints=True;assert console.client.request('CLAIM',{},owner)['ok']
            engine.start(dict(version=1,id='link-loss',name='link-loss',entry='a',blocks=blocks),owner)
            wait(lambda:engine.status().get('current_id')=='a',5);fake.send_heartbeat=False
            wait(lambda:not engine.status()['active'],12)
            status=engine.status();assert status['state']=='failed' and '飞控链路中断' in status['message'],status
            print('PASS: visual loss and block timeout wait, recover using one session, manual stop, basic motion timeout waits, heartbeat failure stops; PTY only')
        finally:
            done.set()
            if console:console.stop()
            if process:
                process.terminate()
                try:process.wait(timeout=8)
                except subprocess.TimeoutExpired:process.kill();process.wait()
            if thread.is_alive():thread.join(2)
            fake.close()
            if hasattr(fake,'error'):raise fake.error
if __name__=='__main__':run()
