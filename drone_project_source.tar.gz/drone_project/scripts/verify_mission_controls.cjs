// Isolated UI checks: only loopback server; no flight actions.
const assert=require('node:assert/strict');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE);
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:process.env.CHROME_PATH});
 try{
  const page=await browser.newPage();let errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.route('**/api/mission/start',r=>r.abort());await page.route('**/api/mission/stop',r=>r.abort());
  await page.goto('http://127.0.0.1:8082/#mission');await page.waitForSelector('.mission-block');
  await page.locator('#mission-collapse').click();assert(await page.locator('#mission-library').isHidden());
  await page.locator('#mission-collapse').click();assert(await page.locator('#mission-library').isVisible());
  await page.locator('#mission-search').fill('距离保持');assert((await page.locator('.mission-block:visible').count())>0);assert((await page.locator('.mission-block:visible').count())<18);
  await page.locator('#mission-search').clear();await page.locator('#preset-mission').click();
  let rows=page.locator('#mission-list > li');assert.equal(await rows.count(),3);
  await rows.first().getByRole('button',{name:'复制 搜索并确认目标'}).click();assert.equal(await rows.count(),4);
  await rows.nth(1).getByRole('button',{name:'上移 搜索并确认目标 · 副本'}).click();assert((await rows.first().innerText()).includes('副本'));
  await rows.first().getByRole('button',{name:'删除 搜索并确认目标 · 副本'}).click();assert.equal(await rows.count(),3);
  await page.locator('#mission-name').fill('控件隔离测试');await page.locator('#mission-save').click();
  await page.waitForFunction(()=>document.getElementById('mission-saved').value!=='');
  let saved=await page.locator('#mission-saved').inputValue();await page.locator('#clear-mission').click();assert.equal(await rows.count(),0);
  await page.locator('#mission-saved').selectOption(saved);await page.locator('#mission-load').click();await page.waitForFunction(()=>document.querySelectorAll('#mission-list > li').length===3);
  const downloadPromise=page.waitForEvent('download');await page.locator('#mission-export').click();const download=await downloadPromise;
  const stream=await download.createReadStream();let chunks=[];for await(const c of stream)chunks.push(c);let data=Buffer.concat(chunks);assert.equal(JSON.parse(data).blocks.length,3);
  await page.locator('#clear-mission').click();await page.locator('#mission-import').setInputFiles({name:'mission.json',mimeType:'application/json',buffer:data});
  await page.waitForFunction(()=>document.querySelectorAll('#mission-list > li').length===3);
  await page.locator('#mission-copy').click();assert.equal(await rows.count(),3);
  assert.deepEqual(errors,[]);console.log('PASS: search, collapse, copy/delete/reorder blocks, save/load, import/export and copy mission on isolated server');
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
