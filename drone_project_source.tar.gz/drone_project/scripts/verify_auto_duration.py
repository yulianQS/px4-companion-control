"""Local-only PTY mission test for automatic forward duration."""
import json, os, socket, subprocess, sys, tempfile, threading, time
from pathlib import Path
from verify_cpp_service import FakePX4, wait
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from web.server.cpp_bridge import FlightConsole
from web.server.mission_client import MissionClient
from web.server.vision_control_config import VisionControlConfig, DEFAULTS

def scenario(binary, mode, offset):
    fake=FakePX4(); done=threading.Event(); process=console=None
    with tempfile.TemporaryDirectory(prefix='auto-duration-pty-') as temp:
        root=Path(temp); (root/'vision').mkdir(); (root/'config').mkdir()
        (root/'config/mission_blocks.json').write_bytes((Path(__file__).resolve().parents[1]/'config/mission_blocks.json').read_bytes())
        VisionControlConfig(root/'config/vision_control.json').save(dict(DEFAULTS,forward_speed_m_s=4.))
        def publisher():
            while not done.is_set():
                stamp=time.monotonic(); sample=dict(source='ros2_cpp',written_monotonic=stamp,observation_monotonic=stamp,camera_ready=True,target_found=True,tag_id=0,center=[319.5,239.5],width=640,height=480,measurement_age_s=.01,pose_valid=True,calibrated=True,tag_size_m=.12,distance_m=2.,translation_m=[0.,0.,2.])
                tmp=root/'vision/status.tmp';tmp.write_text(json.dumps(sample));tmp.replace(root/'vision/status.json');done.wait(.03)
        thread=threading.Thread(target=publisher,daemon=True)
        try:
            with socket.socket() as probe:probe.bind(('127.0.0.1',0));port=probe.getsockname()[1]
            thread.start();fake.thread.start()
            process=subprocess.Popen([str(binary),'--device',fake.device,'--port',str(port),'--logs',str(root/'flights')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=dict(os.environ,DRONE_PROJECT_ROOT=str(root),DRONE_VISION_SNAPSHOT_DIR=str(root/'vision')))
            console=FlightConsole(port=port);console.start(); owner='auto-duration-test'
            state=lambda:console.status()['data']; wait(lambda:state()['px4'].get('bidirectional'),8)
            assert console.client.request('CLAIM',{},owner)['ok'];assert console.client.request('SET_MODE',{'mode':'OFFBOARD'},owner)['confirmed'];assert console.client.request('ARM',{},owner)['confirmed']
            fake.xyz[2]=-.5;fake.landed=2;wait(lambda:state()['px4'].get('landed_state')==2)
            align=dict(id='align',type='align',name='align',branches={},timeout=15,next='distance',params=dict(coarse_alignment_frames=1))
            dist=dict(id='distance',type='distance',name='distance',branches={},timeout=15,next='end',params=dict(duration_mode='auto',duration_offset=offset))
            end=dict(id='end',type='recognize',name='end',branches={},timeout=15,next=None,params=dict(confirm_frames=300))
            blocks=[dist,end] if mode=='missing' else [align,dist,end]
            engine=MissionClient(console);engine.start(dict(version=1,id='auto-test',name='auto-test',entry=blocks[0]['id'],blocks=blocks),owner)
            if mode in ('missing','invalid'):
                wait(lambda:not engine.status()['active'],8);result=engine.status();assert result['state']=='failed',result
                assert not any(e.get('event')=='distance_duration_calculated' for e in result['events'])
                assert not any(e.get('command')=='VISION_UPDATE' and e.get('stage')=='completed' and e.get('elapsed_s',0)>1 for e in result['events'])
            else:
                wait(lambda:engine.status().get('current_id')=='end',8);result=engine.status(); events=result['events']
                calc=next(e for e in events if e['event']=='distance_duration_calculated');complete=next(e for e in events if e['event']=='distance_duration_complete');started=next(e for e in events if e['event']=='block_started' and e['block_id']=='distance')
                assert abs(calc['distance_m']-2)<.001 and abs(calc['speed_m_s']-4)<.001
                assert abs(calc['duration_s']-(.5+offset))<.001,calc
                assert calc['duration_s']<=complete['monotonic_s']-started['monotonic_s']<calc['duration_s']+.35,(calc,complete,started)
        finally:
            done.set()
            if console:console.stop()
            if process:
                process.terminate()
                try:process.communicate(timeout=8)
                except subprocess.TimeoutExpired:process.kill();process.communicate()
            if thread.is_alive():thread.join(2)
            fake.close()
            if hasattr(fake,'error'):raise fake.error
if __name__=='__main__':
    binary=Path(sys.argv[1]).resolve()
    for mode,offset in [('valid',0),('valid',.2),('valid',-.2),('missing',0),('invalid',-.6)]:scenario(binary,mode,offset)
    print('PASS: 2m/4m/s, positive and negative offsets, missing alignment and invalid adjusted duration')
