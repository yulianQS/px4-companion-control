"""Only fake PTY PX4: verify distinct frames and configurable threshold."""
import json,os,socket,subprocess,sys,tempfile,threading,time
from pathlib import Path
from verify_cpp_service import FakePX4,wait
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from web.server.cpp_bridge import FlightConsole
from web.server.mission_client import MissionClient

def run():
 binary=Path(sys.argv[1]).resolve();fake=FakePX4();assert fake.device.startswith('/dev/pts/');done=threading.Event();fresh=threading.Event();visible=threading.Event();visible.set()
 with tempfile.TemporaryDirectory(prefix='frame-confirm-') as d:
  root=Path(d);(root/'vision').mkdir();(root/'config').mkdir();(root/'config/mission_blocks.json').write_bytes((Path(__file__).resolve().parents[1]/'config/mission_blocks.json').read_bytes())
  def publish():
   stamp=time.monotonic()
   while not done.is_set():
    if fresh.is_set():stamp=time.monotonic()
    sample=dict(source='ros2_cpp',written_monotonic=time.monotonic(),observation_monotonic=stamp,camera_ready=True,target_found=visible.is_set(),tag_id=0,center=[319.5,239.5],width=640,height=480,measurement_age_s=.01,pose_valid=True,calibrated=True,tag_size_m=.12,distance_m=2.,translation_m=[0,0,2.])
    p=root/'vision/status.tmp';p.write_text(json.dumps(sample));p.replace(root/'vision/status.json');done.wait(.03)
  th=threading.Thread(target=publish,daemon=True);process=console=None
  try:
   with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
   th.start();fake.thread.start();env=dict(os.environ,DRONE_PROJECT_ROOT=str(root),DRONE_VISION_SNAPSHOT_DIR=str(root/'vision'))
   process=subprocess.Popen([str(binary),'--device',fake.device,'--port',str(port),'--logs',str(root/'flights')],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
   console=FlightConsole(port=port);console.start();owner='frame-confirm-owner';state=lambda:console.status()['data'];wait(lambda:state()['px4'].get('bidirectional'),8)
   assert console.client.request('CLAIM',{},owner)['ok'];assert console.client.request('SET_MODE',{'mode':'OFFBOARD'},owner)['confirmed'];assert console.client.request('ARM',{},owner)['confirmed']
   fake.xyz[2]=-.5;fake.landed=2;wait(lambda:state()['px4'].get('landed_state')==2)
   engine=MissionClient(console)
   blocks=[dict(id='s',type='search',name='search',params=dict(confirm_frames=12),branches={},timeout=30,next='a'),dict(id='a',type='align',name='align',params={},branches={},timeout=30,next=None)]
   engine.start(dict(version=1,id='frames',name='frames',entry='s',blocks=blocks),owner)
   wait(lambda:engine.status().get('current_id')=='s',5);time.sleep(1)
   assert engine.status()['current_id']=='s','frozen repeated snapshot triggered confirmation'
   fresh.set();wait(lambda:engine.status().get('confirmation_frames',0)>=3,5)
   visible.clear();time.sleep(1.2)
   paused=engine.status();assert paused['current_id']=='s' and 3<=paused.get('confirmation_frames',0)<12,paused
   before=paused['confirmation_frames'];time.sleep(.5);assert engine.status()['confirmation_frames']==before
   visible.set();wait(lambda:engine.status().get('current_id')=='a',8)
   events=engine.status()['events'];confirmation=next(e for e in events if e['event']=='search_confirmed')
   assert confirmation['confirmation_frames']>=12,confirmation
   engine.stop('hold');wait(lambda:not engine.status()['active'],5)
   print('PASS: configurable frame threshold, frozen frames never double count, long gaps retain count, fresh frames trigger handoff; fake PTY')
  finally:
   done.set()
   if console:console.stop()
   if process:
    process.terminate()
    try:process.wait(timeout=8)
    except subprocess.TimeoutExpired:process.kill();process.wait()
   if th.is_alive():th.join(2)
   fake.close()
   if hasattr(fake,'error'):raise fake.error
if __name__=='__main__':run()
