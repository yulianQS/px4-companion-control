"""Verify timed forward motion using a local PTY fake PX4 only."""
import json, os, socket, subprocess, sys, tempfile, threading, time
from pathlib import Path
from verify_cpp_service import FakePX4, wait
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from web.server.cpp_bridge import FlightConsole
from web.server.mission_client import MissionClient
from web.server.vision_control_config import VisionControlConfig, DEFAULTS

def run():
    binary = Path(sys.argv[1]).resolve()
    fake = FakePX4(); done = threading.Event(); mode = ['near']; process = console = None
    with tempfile.TemporaryDirectory(prefix='timed-forward-pty-') as temp:
        root=Path(temp); (root/'vision').mkdir(); (root/'config').mkdir()
        (root/'config/mission_blocks.json').write_bytes((Path(__file__).resolve().parents[1]/'config/mission_blocks.json').read_bytes())
        VisionControlConfig(root/'config/vision_control.json').save(dict(DEFAULTS, forward_speed_m_s=.4, target_distance_m=1.))
        def publisher():
            while not done.is_set():
                stamp=time.monotonic(); sample=dict(source='ros2_cpp',written_monotonic=stamp,observation_monotonic=stamp,camera_ready=True,target_found=mode[0]=='near',tag_id=0,center=[319.5,239.5],width=640,height=480,measurement_age_s=.01,pose_valid=True,calibrated=True,tag_size_m=.12,distance_m=1.,translation_m=[0.,0.,1.])
                tmp=root/'vision/status.tmp'; tmp.write_text(json.dumps(sample)); tmp.replace(root/'vision/status.json'); done.wait(.03)
        thread=threading.Thread(target=publisher,daemon=True)
        try:
            with socket.socket() as probe: probe.bind(('127.0.0.1',0)); port=probe.getsockname()[1]
            thread.start(); fake.thread.start()
            process=subprocess.Popen([str(binary),'--device',fake.device,'--port',str(port),'--logs',str(root/'flights')],stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=dict(os.environ,DRONE_PROJECT_ROOT=str(root),DRONE_VISION_SNAPSHOT_DIR=str(root/'vision')))
            console=FlightConsole(port=port); console.start(); owner='timed-forward-test'
            state=lambda:console.status()['data']
            wait(lambda:state()['px4'].get('bidirectional'),8)
            assert console.client.request('CLAIM',{},owner)['ok']; assert console.client.request('SET_MODE',{'mode':'OFFBOARD'},owner)['confirmed']; assert console.client.request('ARM',{},owner)['confirmed']
            fake.xyz[2]=-.5; fake.landed=2; wait(lambda:state()['px4'].get('landed_state')==2)
            blocks=[dict(id='distance',type='distance',name='distance',branches={},timeout=15,next='end',params=dict(duration=3,lost_timeout=.1,lost_target='end')),dict(id='end',type='recognize',name='end',branches={},timeout=15,next=None,params=dict(confirm_frames=300))]
            override=os.environ.get('TEST_FORWARD_OVERRIDE')
            if override: blocks[0]['params']['forward_speed_override']=float(override)
            expected=float(override) if override else .4
            engine=MissionClient(console); engine.start(dict(version=1,id='timed-test',name='timed-test',entry='distance',blocks=blocks),owner)
            wait(lambda:engine.status().get('current_id')=='distance',5)
            wait(lambda:state()['motion'].get('phase')=='timed_forward_tracking',5)
            assert abs(state()['motion']['vision_output']['forward_m_s']-expected)<1e-6
            assert abs(fake.setpoints[-1][1].vx-expected)<.02
            mode[0]='missing'; wait(lambda:state()['motion'].get('phase')=='timed_forward_no_target',3)
            time.sleep(.5); assert engine.status()['current_id']=='distance'; assert abs(state()['motion']['vision_output']['forward_m_s']-expected)<1e-6
            wait(lambda:engine.status().get('current_id')=='end',5)
            events=engine.status()['events']; begin=next(e for e in events if e['event']=='block_started' and e['block_id']=='distance'); end=next(e for e in events if e['event']=='distance_duration_complete')
            assert 3 <= end['monotonic_s']-begin['monotonic_s'] < 3.8, (begin,end)
            print('PASS: forward velocity at target distance and during loss; loss branch ignored; timed transition after 3 seconds')
        finally:
            done.set()
            if console: console.stop()
            if process:
                process.terminate()
                try: process.communicate(timeout=8)
                except subprocess.TimeoutExpired: process.kill(); process.communicate()
            if thread.is_alive():thread.join(2)
            fake.close()
            if hasattr(fake,'error'):raise fake.error
if __name__=='__main__':run()
