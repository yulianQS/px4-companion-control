"""Check saved pre-frame missions migrate without converting time to frames."""
from web.server.mission_store import validate

def doc(kind,params):
    return {'version':1,'id':'old','name':'old','entry':'a','blocks':[{'id':'a','type':kind,'params':params,'next':None,'branches':{},'timeout':120}]}
for kind,key in [('search','confirm_seconds'),('recognize','settle_seconds'),('lock','settle_seconds')]:
    for seconds in (.1,.5,10):
        p=validate(doc(kind,{key:seconds}))['blocks'][0]['params']
        assert p['confirm_frames']==15 and key not in p
    p=validate(doc(kind,{key:.5,'confirm_frames':7}))['blocks'][0]['params']
    assert p['confirm_frames']==7
try:validate(doc('search',{'confirm_frames':0}))
except ValueError:pass
else:raise AssertionError('zero frames accepted')
print('PASS: legacy seconds are not converted, custom frame counts preserved and validated')
