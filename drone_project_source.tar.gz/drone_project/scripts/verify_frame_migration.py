"""Check saved pre-frame missions migrate without converting time to frames."""
from web.server.mission_store import validate

def doc(kind,params):
    return {'version':1,'id':'old','name':'old','entry':'a','blocks':[{'id':'a','type':kind,'params':params,'next':None,'branches':{},'timeout':120}]}
for kind,key in [('search','confirm_seconds'),('recognize','settle_seconds'),('lock','settle_seconds')]:
    for seconds in (.1,.5,10):
        p=validate(doc(kind,{key:seconds}))['blocks'][0]['params']
        assert p['confirm_frames']==15 and key not in p
    p=validate(doc(kind,{key:.5,'confirm_frames':7}))['blocks'][0]['params']
    assert p['confirm_frames']==7
for params in ({'settle_seconds':1,'coarse_settle_seconds':.1}, {'settle_seconds':10,'coarse_settle_seconds':5}):
    p=validate(doc('align',params))['blocks'][0]['params']
    assert p['alignment_frames']==15 and p['coarse_alignment_frames']==15
    assert 'settle_seconds' not in p and 'coarse_settle_seconds' not in p
p=validate(doc('align',{'alignment_frames':7,'coarse_alignment_frames':4,'settle_seconds':1}))['blocks'][0]['params']
assert p['alignment_frames']==7 and p['coarse_alignment_frames']==4
try:validate(doc('search',{'confirm_frames':0}))
except ValueError:pass
else:raise AssertionError('zero frames accepted')
print('PASS: legacy seconds are not converted, custom frame counts preserved and validated')
