"""Export saved, user-editable board parameters without logs or credentials."""
from pathlib import Path
import re

CONFIG_FILES = ('runtime.json', 'vision_control.json', 'vision.yaml',
                'camera_intrinsics.yaml', 'camera_intrinsics_source.json')
MISSION_NAME = re.compile(r'^[A-Za-z0-9_-]{1,100}\.json$')
MAX_FILE = 262144


def snapshot(root, mission_store):
    root = Path(root)
    files = {}

    def add(path, relative):
        if path.is_symlink() or not path.is_file():
            return
        data = path.read_bytes()
        if len(data) > MAX_FILE:
            raise ValueError('参数文件过大：' + relative)
        files[relative] = data.decode('utf-8')

    for name in CONFIG_FILES:
        add(root / 'config' / name, 'config/' + name)
    with mission_store.lock:
        for path in sorted((root / 'missions').glob('*.json')):
            if MISSION_NAME.fullmatch(path.name):
                add(path, 'missions/' + path.name)
    if sum(len(value.encode('utf-8')) for value in files.values()) > 8 * 1024 * 1024:
        raise ValueError('参数与任务数据超过 8 MB')
    return {'version': 1, 'files': files}
